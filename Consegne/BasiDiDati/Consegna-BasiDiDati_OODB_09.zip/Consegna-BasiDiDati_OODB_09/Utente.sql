insert into utente (username, nome, cognome, titolo, email, password, id_ente) values 
('Giordi9902','Giorgio','Di Fusco',null,'giorgio99difusco@gmail.com','giorgio',31),
('SuoXender','Antonio', 'Caporaso', null, 'anto.caporaso00@gmail.com','mandarino',31),
('Robbin', 'Vail', 'Bourtoumieux', 'Professore', 'vbourtoumieux0@imageshack,us', 'wA8%''\dB\59Z', 2),
('Rakel', 'Penrod', 'Gurnee', 'Ingegnere', 'pgurnee1@cocolog-nifty,com', 'wY9}eZP&CE1KwjxL', 11),
('Enrico', 'Geordie', 'Grollmann', 'Assistente', 'ggrollmann2@alibaba,com', 'fH1&97avP!MQ', 26),
('Almira', 'Vere', 'Lamberth', null, 'vlamberth3@exblog,jp', 'vI4=LuClV,wKGG', 26),
('Bev', 'Allsun', 'Caney', 'Dottoressa', 'acaney4@gizmodo,com', 'mM1(Wu,q2)', 26),
('Cozmo', 'Shantee', 'Wathan', 'Dottoressa', 'swathan5@scientificamerican,com', 'eL0>8v}K', 11),
('Lynnelle', 'Prince', 'McClaurie', null, 'pmcclaurie6@myspace,com', 'nE4#}!k~=g,p', 24),
('Chas', 'Rachele', 'Murkitt', null, 'rmurkitt7@constantcontact,com', 'qP2{!OA\83Rd`', 3),
('Drona', 'Spike', 'Queste', null, 'squeste8@gmpg,org', 'aY8$),+LAh`', 4),
('Martelle', 'Jacobo', 'Martinec', 'Ingegnere', 'jmartinec9@state,gov', 'tY2>&pUg', 11);
