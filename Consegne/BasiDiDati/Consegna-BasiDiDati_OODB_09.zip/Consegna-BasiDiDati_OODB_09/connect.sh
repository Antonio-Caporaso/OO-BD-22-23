#! /bin/bash
psql -h database-oobd.ct0ckvilfzkl.eu-central-1.rds.amazonaws.com -p 5432 -d OO_DB -U Master_User
