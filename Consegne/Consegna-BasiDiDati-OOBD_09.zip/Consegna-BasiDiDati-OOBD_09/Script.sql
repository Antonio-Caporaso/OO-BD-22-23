drop schema conference cascade;
\i Tables.sql
\i Funzioni.sql
\i Triggers.sql
\i Views.sql
\i Enti.sql
\i Organizzatori.sql
\i Sedi.sql
\i Sale.sql
\i Utente.sql
\i Speaker.sql
\i Sponsors.sql
\i Valute.sql
\i PGConfNPL.sql
\i SpaceExpo.sql
\i GlobalTechSummit.sql
\i RoboticsSummit.sql