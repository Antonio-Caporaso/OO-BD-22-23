SET search_path TO conference;
INSERT INTO valuta (iso,nome,simbolo)
VALUES  ('USD', 'United States Dollar', '$'),
        ('EUR', 'Euro', '€'),
        ('JPY', 'Japanese Yen', '¥'),
        ('GBP', 'British Pound Sterling', '£'),
        ('CAD', 'Canadian Dollar', 'CA$');