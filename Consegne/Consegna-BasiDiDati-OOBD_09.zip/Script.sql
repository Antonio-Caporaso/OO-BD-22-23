drop schema conference cascade;
\i Tabelle/Tables.sql
\i TriggerProcedure/Funzioni.sql
\i TriggerProcedure/Triggers.sql
\i Viste/Views.sql
\i Popolamento/Enti.sql
\i Popolamento/Organizzatori.sql
\i Popolamento/Sedi.sql
\i Popolamento/Sale.sql
\i Popolamento/Utente.sql
\i Popolamento/Speaker.sql
\i Popolamento/Sponsors.sql
\i Popolamento/Valute.sql
\i Popolamento/PGConfNPL.sql
\i Popolamento/SpaceExpo.sql
\i Popolamento/GlobalTechSummit.sql
\i Popolamento/RoboticsSummit.sql
